package  com.porvenir.util;

public class Constant {

    private Constant() {
        throw new IllegalStateException("Utility class");
    }
    public static final String CONSTANTE_UNO = "Valor";
}