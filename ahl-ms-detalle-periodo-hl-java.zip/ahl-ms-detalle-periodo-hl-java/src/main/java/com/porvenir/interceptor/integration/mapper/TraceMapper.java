package com.porvenir.interceptor.integration.mapper;

import com.porvenir.interceptor.dto.LoggerDto;
import com.porvenir.interceptor.integration.dto.TraceDto;

public interface TraceMapper {
   // TraceDto toTrace(LoggerDto loggerDto);
}
