package com.porvenir.interceptor.mapper;

public class InterceptorMapperImpl implements InterceptorMapper {
}