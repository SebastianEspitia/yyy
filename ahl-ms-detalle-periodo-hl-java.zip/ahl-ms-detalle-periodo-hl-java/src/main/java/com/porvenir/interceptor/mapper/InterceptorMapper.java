package com.porvenir.interceptor.mapper;

public interface InterceptorMapper {
}